﻿using Microsoft.AspNetCore.Mvc;

namespace FootBall.API.Controllers
{
    using FootBall.API.Interfaces;
    using FootBall.API.Models;

    [ApiController]
    [Route("[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ILogger<CustomerController> _logger;
        private ICustomerService _customer;

        public CustomerController(ILogger<CustomerController> logger, ICustomerService customer)
        {
            _logger = logger;
            _customer = customer;
        }

        [HttpGet(Name = "GetAllCustomers")]
        public Customer GetCustomers([FromQuery] Customer customer) => _customer.GetConcretteCustomer(customer);
    }
}
