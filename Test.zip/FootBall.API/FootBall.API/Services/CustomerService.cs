﻿namespace FootBall.API.Services
{
    using FootBall.API.Interfaces;
    using FootBall.API.Models;

    public class CustomerService : ICustomerService
    {
        public Customer GetConcretteCustomer(Customer customer)
        {
            if (customer.Name.Length < 3)
            {
                return null;
            }
            return customer;
        }
    }
}
