﻿namespace FootBall.API.Interfaces
{
    using FootBall.API.Models;

    public interface ICustomerService
    {
        Customer GetConcretteCustomer(Customer customer);
    }
}
